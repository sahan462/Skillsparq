# OOFP-warmup

Do not post solution of this assignment online! This is considered plagiarism by the exam board (this holds for all courses at the VU unless specified otherwise). 

