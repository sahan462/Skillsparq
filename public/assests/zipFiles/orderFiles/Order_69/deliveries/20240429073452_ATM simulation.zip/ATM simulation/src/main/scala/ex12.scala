object ex12 {

  // METHOD TO CHOOSE THE CLIENT TO PROCESS
  def chooseClient(arrayID: Array[Int], arrayPIN: Array[String]): Int = {
    import scala.io.StdIn._
    var identifier: Int = 0
    var pinInsert = ""
    var enteredIdentifier: Int = 0
    do {
      do {
        println("Enter your identifier code:")
        enteredIdentifier = readInt()
        if (!arrayID.contains(enteredIdentifier)) {
          println("This identifier is not valid.")
          sys.exit()
        }
      } while (!arrayID.contains(enteredIdentifier))

      var attempt = 0
      val maxAttempts = 3
      var remainingAttempts = maxAttempts

      do {
        println("Enter your PIN code:")
        pinInsert = readLine()
        if (pinInsert != arrayPIN(enteredIdentifier)) {
          attempt = attempt + 1
          remainingAttempts = maxAttempts - attempt
          println(s"Incorrect PIN code, $remainingAttempts attempts remaining.")
        }
      } while (remainingAttempts > 0 && pinInsert != arrayPIN(enteredIdentifier))

      if (remainingAttempts == 0) {
        println("Too many errors, abandoning identification.")
        remainingAttempts = maxAttempts
      }
    } while (pinInsert != arrayPIN(enteredIdentifier))

    identifier
  }




  // METHOD TO VIEW AND CHOOSE MENU OPTION
  def selectMenu(): Int = {
    import scala.io.StdIn._
    var selectedOption: Int = 0
    val menu = "Choose your operation:\n 1) Deposit \n 2) Withdrawal \n 3) Account Inquiry \n 4) Change PIN \n 5) Finish \n Your choice:"
    do {
      println(menu)
      selectedOption = readInt()
    } while (selectedOption == 0 || selectedOption > 5)
    selectedOption
  }




  // METHOD TO MAKE A DEPOSIT TO THE ACCOUNT
  def deposit(id: Int, accounts: Array[Double]): Unit = {

    import scala.io.StdIn._
    var totalAmount = accounts(id)
    var insertedAmount = 0
    var convertedAmount: Double = 0.0
    var currency = 1
    val CHF = 1
    val EURtoCHF: Double = 0.95

    // CHOOSE THE CURRENCY FOR DEPOSIT
    do {
      println("Indicate the deposit currency:\n 1) CHF \n 2) EUR ")
      currency = readInt()
    } while (currency == 0 || currency > 2)

    // ASK AND READ INSERTED AMOUNT
    do {
      println("Indicate the deposit amount:")
      insertedAmount = readInt()
      if (insertedAmount % 10 != 0) {
        println("The amount must be a multiple of 10.")
      }
    } while (insertedAmount % 10 != 0)

    // CALCULATE THE NEW TOTAL AMOUNT IN CHF AND DISPLAY TO THE CLIENT
    if (currency == CHF) {
      totalAmount = totalAmount + insertedAmount
    } else {
      convertedAmount = insertedAmount * EURtoCHF
      totalAmount = totalAmount + convertedAmount
    }

    // SAVE THE NEW AMOUNT
    accounts(id) = totalAmount
    println(s"Your deposit has been processed. The new amount is: $totalAmount CHF")
  }




  // METHOD FOR ACCOUNT WITHDRAWAL
  def withdrawal(id: Int, accounts: Array[Double]): Unit = {
    import scala.io.StdIn._
    var currencyString = "CHF"
    var currency = 1
    var withdrawalAmount = 0
    var totalAmount = accounts(id)
    var remainingAmount = 0
    var convertedAmount: Double = 0.00
    val CHF = 1
    val EURtoCHF: Double = 0.95
    var denominationsChoice = 2
    var denominations: Array[Int] = Array(500, 200, 100, 50)
    val largerDenominations: Array[Int] = Array(500, 200, 100, 50, 20, 10)
    val smallerDenominations: Array[Int] = Array(100, 50, 20, 10)
    var arrayPosition = -1
    var finalArrayPosition = -1
    var bills = 0
    var finalBills: Array[Int] = Array(0, 0, 0, 0, 0, 0)
    var finalDenominations: Array[Int] = Array(0, 0, 0, 0, 0, 0)
    var denominationsDecision = "o"
    var acceptedDenominations = 0
    var denominationsQuantity = 0
    var denominationsValue = 0




    // CHOOSE THE CURRENCY FOR WITHDRAWAL
    do {
      println("Indicate the currency:\n 1) CHF \n 2) EUR ")
      currency = readInt()
      if (currency == 2) {
        currencyString = "EUR"
      }
    } while (currency == 0 || currency > 2)

    // CHOOSE THE WITHDRAWAL AMOUNT
    do {
      println("Indicate the withdrawal amount:")
      withdrawalAmount = readInt()
      if (withdrawalAmount % 10 != 0) {
        println("The amount must be a multiple of 10.")
      }
      if (withdrawalAmount > totalAmount * 0.1) {
        println(s"Your authorized withdrawal limit is: ${totalAmount * 0.1 * 1.05} $currencyString")
      }
    } while (withdrawalAmount % 10 != 0 || withdrawalAmount > totalAmount * 0.1)

    // CHOOSE DENOMINATIONS FOR WITHDRAWAL
    if (withdrawalAmount >= 200 && currency == CHF) {
      do {
        println("In:\n 1) Larger denominations \n 2) Smaller denominations ")
        denominationsChoice = readInt()
        if (denominationsChoice == 1) {
          denominations = largerDenominations
        } else {
          denominations = smallerDenominations
        }
      } while (currency == 0 || currency > 2)
    } else {
      denominations = smallerDenominations
    }




    // NUMBER OF DENOMINATIONS TO WITHDRAW
    remainingAmount = withdrawalAmount
    do {
      // OPTION OF LARGER BILL TO GIVE
      do {
        bills = 0
        arrayPosition = arrayPosition + 1
        denominationsValue = denominations(arrayPosition)
        if (remainingAmount / denominationsValue > 0) {
          bills = remainingAmount / denominationsValue
        }
      } while (bills == 0)

      println(s"There is $remainingAmount $currencyString left to distribute.")
      println(s"You can get a maximum of $bills bill(s) of $denominationsValue $currencyString.")
      println("Type 'o' for ok or any other value lower than the proposed one.")
      denominationsDecision = readLine()



      // MAXIMUM DENOMINATION NOT ACCEPTED
      if (denominationsDecision != "o") {
        do {
          acceptedDenominations = denominationsDecision.toInt
          if (acceptedDenominations == 0) {
            do {
              bills = 0
              arrayPosition = arrayPosition + 1
              denominationsValue = denominations(arrayPosition)
              if (remainingAmount / denominationsValue > 0) {
                bills = remainingAmount / denominationsValue
              }
            } while (bills == 0)
          } else if (acceptedDenominations > bills) {
            println("Type a value lower than the proposed one.")
            denominationsDecision = readLine()
          } else if (acceptedDenominations < bills) {
            acceptedDenominations = denominationsDecision.toInt
            finalArrayPosition = finalArrayPosition + 1
            remainingAmount = remainingAmount - (acceptedDenominations * denominationsValue)
            finalBills(finalArrayPosition) = acceptedDenominations
            finalDenominations(finalArrayPosition) = denominationsValue
            bills = 0

            do {
              bills = 0
              arrayPosition = arrayPosition + 1
              denominationsValue = denominations(arrayPosition)
              if (remainingAmount / denominationsValue > 0) {
                bills = remainingAmount / denominationsValue
              }
            } while (bills == 0)
          }

          println(s"There is $remainingAmount $currencyString left to distribute.")
          println(s"You can get a maximum of $bills bill(s) of $denominationsValue $currencyString.")
          println("Type 'o' for ok or any other value lower than the proposed one.")
          denominationsDecision = readLine()

        } while (denominationsDecision != "o")
      }



      // ACCEPTED DENOMINATION
      if (denominationsDecision == "o") {
        finalArrayPosition = finalArrayPosition + 1
        remainingAmount = remainingAmount - (bills * denominationsValue)
        finalBills(finalArrayPosition) = bills
        finalDenominations(finalArrayPosition) = denominationsValue
      }

    } while (remainingAmount > 0)



    // FINAL WITHDRAWAL
    println("Please withdraw the requested amount:")
    for (i <- 0 to 5) {
      if (finalBills(i) > 0 && finalDenominations(i) > 0) {
        println(s"${finalBills(i)} bill(s) of ${finalDenominations(i)} $currencyString.")
      }
    }

    // REMAINING AMOUNT AFTER WITHDRAWAL
    if (currency == CHF) {
      totalAmount = totalAmount - withdrawalAmount
    } else {
      convertedAmount = withdrawalAmount * EURtoCHF
      totalAmount = totalAmount - convertedAmount
    }

    accounts(id) = totalAmount
    println(s"Your withdrawal has been processed. The new available amount on your account is: $totalAmount")
  }



  // METHOD TO CHANGE THE ACCOUNT PIN
  def changePin(id: Int, pinCodes: Array[String]): Unit = {
    import scala.io.StdIn._
    var newPin = "INTRO1234"

    // ASK FOR THE NEW PIN
    do {
      println("Enter your new PIN code (it must contain at least 8 characters):")
      newPin = readLine()
      if (newPin.length < 8) {
        println("Your PIN code must contain at least 8 characters.")
      }
    } while (newPin.length < 8)

    // SAVE THE NEW PIN
    pinCodes(id) = newPin
    println("Your PIN code has been changed successfully.")
  }



  // MAIN PROGRAM
  def main(args: Array[String]): Unit = {
    import scala.io.StdIn._
    val numClients = 100
    var accountIDs: Array[Int] = Array.range(1, numClients)
    var initialAccounts: Array[Double] = Array.fill(numClients)(1200)
    var accounts: Array[Double] = initialAccounts
    var pinCodes: Array[String] = Array.fill(numClients)("INTRO1234")

    var clientID = 0
    var option = 0

    clientID = chooseClient(accountIDs, pinCodes)

    do {
      option = selectMenu()

      if (option == 1) {
        deposit(clientID, accounts)
      }
      if (option == 2) {
        withdrawal(clientID, accounts)
      }
      if (option == 3) {
        println(s"The available amount on your account is: ${accounts(clientID)} CHF.")
      }
      if (option == 4) {
        changePin(clientID, pinCodes)
      }
      if (option == 5) {
        println("End of operations. Don't forget to retrieve your card.")
        clientID = chooseClient(accountIDs, pinCodes)
      }
    } while (option != 0)
  }
}
